
package Modelo;


public class Usuarios {
    public int cod;
    public String user,pasword,nom,nivel;

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPasword() {
        return pasword;
    }

    public void setPasword(String pasword) {
        this.pasword = pasword;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public Usuarios(int cod, String user, String pasword, String nom, String nivel) {
        this.cod = cod;
        this.user = user;
        this.pasword = pasword;
        this.nom = nom;
        this.nivel = nivel;
    }

    public Usuarios() {
    }
     
}
