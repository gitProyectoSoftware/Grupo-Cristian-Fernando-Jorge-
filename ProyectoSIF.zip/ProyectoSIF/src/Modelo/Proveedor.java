package Modelo;

public class Proveedor {

    public long cod;
    public String nom;
    public int telef;
    public String direc, correo;

    public Proveedor() {
    }

    public Proveedor(long cod, String nom, int telefono, String direc, String correo) {
        this.cod = cod;
        this.nom = nom;
        this.telef= telefono;
        this.direc = direc;
        this.correo = correo;

    }

    public long getCod() {
        return cod;
    }

    public void setCod(long cod) {
        this.cod = cod;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getTelefono() {
        return telef;
    }

    public void setTelefono(int telefono) {
        this.telef = telefono;
    }

    public String getDirec() {
        return direc;
    }

    public void setDirec(String direc) {
        this.direc = direc;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
