package Modelo;


public class Productos {
    public long cod;
    public String nom,tipo;
    public int Stock;
    double precio;
    public String lot,fecha;

    public Productos() {
    }

    public Productos(long cod, String nom, String tipo, int Stock, double precio, String lot, String fecha) {
        this.cod = cod;
        this.nom = nom;
        this.tipo = tipo;
        this.Stock = Stock;
        this.precio = precio;
        this.lot = lot;
        this.fecha = fecha;
    }

    public long getCod() {
        return cod;
    }

    public void setCod(long cod) {
        this.cod = cod;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getLot() {
        return lot;
    }

    public void setLot(String lot) {
        this.lot = lot;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}
