package Modelo;

public class Clientes {

    public long cod;
    public String nom, ApeP,ApeM;
    public int CI,Tel;

    public Clientes() {
    }

    public Clientes(long cod, String nom, String ApeP, String ApeM, int CI, int Tel) {
        this.cod = cod;
        this.nom = nom;
        this.ApeP = ApeP;
        this.ApeM = ApeM;
        this.CI = CI;
        this.Tel = Tel;
    }
    

    public long getCod() {
        return cod;
    }

    public void setCod(long cod) {
        this.cod = cod;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApeP() {
        return ApeP;
    }

    public void setApeP(String ApeP) {
        this.ApeP = ApeP;
    }

    public String getApeM() {
        return ApeM;
    }

    public void setApeM(String ApeM) {
        this.ApeM = ApeM;
    }

    public int getCI() {
        return CI;
    }

    public void setCI(int CI) {
        this.CI = CI;
    }

    public int getTel() {
        return Tel;
    }

    public void setTel(int Tel) {
        this.Tel = Tel;
    }

   
    
   
  

}
