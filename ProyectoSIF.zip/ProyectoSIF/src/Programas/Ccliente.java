package Programas;

import Modelo.Clientes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Ccliente {
    
ConexionBD cone = new ConexionBD();
    public ArrayList recuperaDatos(ResultSet rs)
    {
          ArrayList<Clientes> lclie = new ArrayList();    
        try{
          while (rs.next()) {
                Clientes clie = new Clientes();
                clie.setCod(rs.getInt("Cod_Cliente"));
                clie.setNom(rs.getString("Nombre"));
                clie.setApeP(rs.getString("Apellido_Paterno"));
                clie.setApeM(rs.getString("Apellido_Materno"));
                clie.setCI(rs.getInt("CI"));
                clie.setTel(rs.getInt("Telefono"));
                lclie.add(clie);
            } 
    }catch(SQLException e){  
            JOptionPane.showMessageDialog(null, "Error"+e.getMessage());
    }
        return lclie;
    }
        
    public ArrayList listarClientes() {

        ArrayList<Clientes> lclie = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from clientes";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
           lclie = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ccliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lclie;
    }
    
        public ArrayList listarClieNombre(String nom) {
            
        ArrayList<Clientes> lclie = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from clientes where Nombre like '"+nom+"%'";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lclie = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ccliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lclie;
    }
        
           public void adiciona(Clientes clie)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "INSERT INTO clientes(Cod_cliente,Nombre,Apellido_Paterno,Apellido_Materno,CI,Telefono) values("+clie.getCod()+",'"+clie.getNom()+"','"+clie.getApeP()+"','"+clie.getApeM()+"',"+clie.getCI()+","+clie.getTel()+")";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
        
          public void modifica(Clientes clie)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "update  clientes set  Nombre='"+clie.getNom()+"', Apellido_Paterno='"+clie.getApeP()+"', Apellido_Materno= '"+clie.getApeM()+"', CI="+clie.getCI()+",Telefono= "+clie.getTel()+" where Cod_cliente = "+clie.getCod()+"";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ccliente.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
            public void elimina(long cod)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "delete  from clientes where Cod_cliente = "+cod+"";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ccliente.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
}
