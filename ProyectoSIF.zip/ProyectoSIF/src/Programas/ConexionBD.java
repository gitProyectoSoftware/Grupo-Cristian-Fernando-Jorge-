package Programas;

import java.sql.*;

public class ConexionBD {

    Connection con = null;

    public Connection conecta() {
        String dbURL = "jdbc:mysql://localhost:3306/sif";
        String user = "root";
        String clave = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbURL, user, clave);
            return con;
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Error de conexion"+ex.getMessage());
        } 
      return con ;
    }}
