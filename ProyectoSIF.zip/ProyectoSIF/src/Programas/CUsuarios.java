package Programas;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CUsuarios {

    ConexionBD cone = new ConexionBD();
    int cod;
    String user, pasword, nom, nivel;

    public boolean verifica(String user1, String pasword1) {
        boolean sw = false;
        Connection con = null;
        try {
            con = cone.conecta();
            String sql = "select * from cuenta where Usuario = '" + user1 + "' and pasword = '" + pasword1 + "'";
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            if (rs.next()) {
                user = rs.getString("Usuario");
                pasword = rs.getString("Pasword");
                if (user.equals(user1) && pasword.equals(pasword1)) {
                    sw = true;
                }
            } 
            rs.close();
            smt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CUsuarios.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sw;
    }
}
