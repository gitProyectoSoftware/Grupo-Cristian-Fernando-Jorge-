package Programas;
import java.sql.*;

public class Prueba {
    

    public static void main(String arg[]) {
        ConexionBD cone = new ConexionBD();
        Connection con;
        con = cone.conecta();
        String c="123";
        Hash ha=new Hash();
         String pasword = ha.md5(c);
         System.out.println("pasword "+pasword );
        if (con != null) {
            System.out.println("se conecto a la BD");
        } else {
            System.out.print("no se conecto la BD");
        }
    }
}
