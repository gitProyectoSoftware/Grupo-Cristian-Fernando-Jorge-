package Programas;

import Modelo.Productos;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Cproducto {

    ConexionBD cone = new ConexionBD();
    public ArrayList recuperaDatos(ResultSet rs)
    {
          ArrayList<Productos> lprod = new ArrayList();    
        try{
          while (rs.next()) {
                Productos prod = new Productos();
                prod.setCod(rs.getInt("Cod_producto"));
                prod.setNom(rs.getString("Nombre"));
                prod.setTipo(rs.getString("Tipo"));
                prod.setStock(rs.getInt("Stock"));
                prod.setPrecio(rs.getDouble("Precio"));
                prod.setLot(rs.getString("Lote"));
                prod.setFecha(rs.getString("Fecha_vencimiento"));
                lprod.add(prod);
            } 
    }catch(SQLException e){  
            JOptionPane.showMessageDialog(null, "Error"+e.getMessage());
    }
        return lprod;
    }
        
    public ArrayList listarProductos() {

        ArrayList<Productos> lprod = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from productos";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
           lprod = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprod;
    }
    
        public ArrayList listarProdNombre(String nom) {
            
        ArrayList<Productos> lprod = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from productos where Nombre like '"+nom+"%'";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lprod = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprod;
    }
        public void adiciona(Productos prod)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "INSERT INTO productos( Nombre, Tipo, Stock, Precio, Lote, Fecha_vencimiento) values('"+prod.getNom()+"','"+prod.getTipo()+"',"+prod.getStock()+","+prod.getPrecio()+",'"+prod.getLot()+"','"+prod.getFecha()+"')";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
        
          public void modifica(Productos prod)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "update  productos set Nombre='"+prod.getNom()+"', Tipo='"+prod.getTipo()+"', Stock="+prod.getStock()+", Precio= "+prod.getPrecio()+", Lote='"+prod.getLot()+"',Fecha_vencimiento= '"+prod.getFecha()+"' where Cod_producto = "+prod.getCod()+"";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
          
          public void Elimina(long cod)
        {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "delete from productos  where Cod_producto = "+cod+"";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cproducto.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        }
}
