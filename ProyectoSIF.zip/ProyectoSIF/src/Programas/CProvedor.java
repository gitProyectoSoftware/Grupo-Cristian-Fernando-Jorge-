package Programas;

import Modelo.Proveedor;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CProvedor {

    ConexionBD cone = new ConexionBD();

    public ArrayList recuperaDatos(ResultSet rs) {
        ArrayList<Proveedor> lprov = new ArrayList();
        try {
            while (rs.next()) {
                Proveedor prov = new Proveedor();
                prov.setCod(rs.getInt("Cod_proveedor"));
                prov.setNom(rs.getString("Nombre"));
                prov.setTelefono(rs.getInt("Telefono"));
                prov.setDirec(rs.getString("Direccion"));
                prov.setCorreo(rs.getString("Correo_electronico"));
                lprov.add(prov);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
        }
        return lprov;
    }

    public ArrayList listarProvedor() {

        ArrayList<Proveedor> lprov = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from Proveedor";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lprov = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CProvedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprov;
    }

    public ArrayList listarProvNombre(String nom) {

        ArrayList<Proveedor> lprov = new ArrayList();
        Connection con;
        con = cone.conecta();
        String sql = "select * from Proveedor where Nombre like '" + nom + "%'";
        try {
            Statement smt = con.createStatement();
            ResultSet rs = smt.executeQuery(sql);
            lprov = recuperaDatos(rs);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CProvedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lprov;

    }

    public void adiciona(Proveedor prov) {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "INSERT INTO proveedor( Nombre, Telefono, Direccion, Correo_electronico)values('" + prov.getNom() + "'," + prov.getTelefono() + ",'" + prov.getDirec() + "','" + prov.getCorreo() + "')";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CProvedor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void modifica(Proveedor prov) {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "update  proveedor set Nombre='" + prov.getNom() + "',Telefono=" + prov.getTelefono() + ",Direccion='" + prov.getDirec() + "',Correo_electronico='" + prov.getCorreo() + "' where Cod_proveedor= " + prov.getCod() + "";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CProvedor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Elimina(long cod) {
        try {
            Connection con;
            con = cone.conecta();
            String sql = "delete from proveedor where Cod_proveedor=" + cod + "";
            Statement smt = con.createStatement();
            smt.executeUpdate(sql);
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(CProvedor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
