package Formularios;

import Modelo.Proveedor;
import Programas.CProvedor;
import Programas.ConexionBD;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author jorghe luis sirpa
 */
public class FormProveedor extends javax.swing.JFrame {

    CProvedor cprov = new CProvedor();

    long cod;
    String nom;
    int telef;
    String direc, correo;
    int op = 0;

    public FormProveedor() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/Minifarmacia.png")).getImage());
        setBounds(50, 50, 950, 600);
        habilitaDatos(false);
        listadoGeneral();
        nom="%";
    }

    void recuperaDatosTabla() {
        int fila = jTable1.getSelectedRow();
        jtxtCodigo.setText(jTable1.getValueAt(fila, 0).toString());
        jtxtNombre.setText(jTable1.getValueAt(fila, 1).toString());
        jtxttelef.setText(jTable1.getValueAt(fila, 2).toString());
        jtxtDirecc.setText(jTable1.getValueAt(fila, 3).toString());
        jtxtcorreo.setText(jTable1.getValueAt(fila, 4).toString());
    }

    boolean validaDatos() {
        boolean sw = true;
        if (jtxtNombre.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el nombre", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtNombre.requestFocus();;
        } else if (jtxttelef.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el telefono", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxttelef.requestFocus();;
        } else if (jtxtDirecc.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar la Direccion", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtDirecc.requestFocus();;
        } else if (jtxtcorreo.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el Correo", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtcorreo.requestFocus();;

        }
        return sw;
    }

    void limpiaDatos() {

        jtxtCodigo.setText("");
        jtxtNombre.setText("");
        jtxttelef.setText("");
        jtxtDirecc.setText("");
        jtxtcorreo.setText("");

    }

    void Botones(boolean nuevo, boolean grabar, boolean mod, boolean del, boolean buscar, boolean imprime, boolean salir) {
        btnNuevo.setEnabled(nuevo);
        btnAgrega2.setEnabled(grabar);
        btnModificar.setEnabled(mod);
        btnEliminar.setEnabled(del);
        btnBuscar.setEnabled(buscar);
        btnImprime.setEnabled(imprime);
        btnSalir.setEnabled(salir);
    }

    void recuperaDatos() {
        try {
            cod = Long.parseLong(jtxtCodigo.getText());
            nom = jtxtNombre.getText();
            telef = Integer.parseInt(jtxttelef.getText());
            direc = jtxtDirecc.getText();
            correo = jtxtcorreo.getText();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Uno de los datos numericos esta incorrecto ", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    void Eimina() {
        
        int resp;
        int fila =jTable1.getSelectedRow();
        cod=Integer.parseInt(jTable1.getValueAt(fila,0).toString());
        resp= JOptionPane.showConfirmDialog(this, "Desea eliminar","INFORMACION - SIF ",JOptionPane.YES_NO_OPTION);
        if(resp==0)
        {    
        cprov.Elimina(cod);
        listadoGeneral();
        JOptionPane.showMessageDialog(this, "Datos Eliminados ", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
    }
         
}
    void habilitaDatos(boolean hab) {
        jtxtCodigo.setEnabled(hab);
        jtxtNombre.setEnabled(hab);
        jtxttelef.setEnabled(hab);
        jtxtDirecc.setEnabled(hab);
        jtxtcorreo.setEnabled(hab);
    }

    void listadoGeneral() {
        ArrayList<Proveedor> lprov = new ArrayList();
        lprov = cprov.listarProvedor();
        mostrar(lprov);
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }
    }

    void mostrar(ArrayList<Proveedor> lprov) {
        String mat[][] = new String[lprov.size()][5];
        int i;
        for (i = 0; i < lprov.size(); i++) {
            mat[i][0] = lprov.get(i).getCod() + "";
            mat[i][1] = lprov.get(i).getNom();
            mat[i][2] = lprov.get(i).getTelefono() + "";
            mat[i][3] = lprov.get(i).getDirec() + "";
            mat[i][4] = lprov.get(i).getCorreo() + "";
        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Codigo", "Nombre", "Telefono", "Direccion", "Correo"
                }
        ));
    }

    void listado() {
        nom = "";
        nom = JOptionPane.showInputDialog("Nombre del Provedor a buscar", "");
        if (nom.isEmpty()) {
            ArrayList<Proveedor> lprov = new ArrayList();
            lprov = cprov.listarProvedor();
            mostrar(lprov);
        } else {
            ArrayList<Proveedor> lprov = new ArrayList();
            lprov = cprov.listarProvNombre(nom);
            mostrar(lprov);
        }
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField6 = new javax.swing.JTextField();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jLabel1 = new javax.swing.JLabel();
        jtxtCodigo = new javax.swing.JTextField();
        jtxtNombre = new javax.swing.JTextField();
        jtxttelef = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JToggleButton();
        btnEliminar = new javax.swing.JToggleButton();
        btnAgrega2 = new javax.swing.JToggleButton();
        btnModificar = new javax.swing.JToggleButton();
        btnBuscar = new javax.swing.JToggleButton();
        btnImprime = new javax.swing.JToggleButton();
        btnSalir = new javax.swing.JToggleButton();
        jtxtDirecc = new javax.swing.JTextField();
        jtxtcorreo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();

        jMenuItem1.setText("Eliminar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("Modificar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Courier New", 3, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PROVEEDORES");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 320, 44));

        jtxtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigoActionPerformed(evt);
            }
        });
        jtxtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCodigoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 170, 30));

        jtxtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtNombreActionPerformed(evt);
            }
        });
        jtxtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 170, 30));

        jtxttelef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxttelefActionPerformed(evt);
            }
        });
        jtxttelef.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxttelefKeyTyped(evt);
            }
        });
        getContentPane().add(jtxttelef, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 170, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Direccion");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Codigo:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 70, 20));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Nombre:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 90, 20));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Correo");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 70, 20));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("Telefono");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 80, 20));

        btnNuevo.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/listar.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, 140, 40));

        btnEliminar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 130, 150, 40));

        btnAgrega2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnAgrega2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agrega.png"))); // NOI18N
        btnAgrega2.setText("Grabar");
        btnAgrega2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgrega2ActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgrega2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, 150, 40));

        btnModificar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/modificar.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 130, 150, 40));

        btnBuscar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscar.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 140, 40));

        btnImprime.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnImprime.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/impresora.png"))); // NOI18N
        btnImprime.setText("Imprimir");
        btnImprime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimeActionPerformed(evt);
            }
        });
        getContentPane().add(btnImprime, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 70, -1, 40));

        btnSalir.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/atras (1).png"))); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setToolTipText("");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 210, 140, 40));

        jtxtDirecc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDireccActionPerformed(evt);
            }
        });
        jtxtDirecc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtDireccKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtDirecc, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 170, 30));

        jtxtcorreo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtcorreoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtcorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 170, 30));

        jTable1.setBackground(new java.awt.Color(51, 51, 51));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Telefono", "Direcion", "Correo"
            }
        ));
        jTable1.setComponentPopupMenu(jPopupMenu1);
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 920, 260));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondoProve.png"))); // NOI18N
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, -160, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        listado();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnImprimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimeActionPerformed
        try {
            ConexionBD cone = new ConexionBD();
            Connection con = null;
            con = cone.conecta();
            String archivo = "C:/Users/jorge luis/Documents/NetBeansProjects/ProyectoSIF/src/Reprortes/ReporteProveedor.jasper";
            JasperReport reporte = null;
            reporte = (JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro = new HashMap();
            nom = nom + "%";
            parametro.put("Nom", nom);
            jp = JasperFillManager.fillReport(reporte,parametro, con);
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setTitle("REPORTES DE PROVEEDORES");
            jv.setVisible(true);
        } catch (JRException ex) {

        }
        
        
    }//GEN-LAST:event_btnImprimeActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        if (btnSalir.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        } else {
            FormPrincipal obj = new FormPrincipal();
        obj.setVisible(true);
        this.setVisible(false);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jtxtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodigoKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();

        }
    }//GEN-LAST:event_jtxtCodigoKeyTyped

    private void jtxtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNombreKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtNombreKeyTyped

    private void btnAgrega2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgrega2ActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();

            if (op == 0) {
                Proveedor prov = new Proveedor(0, nom, telef, direc, correo);
                cprov.adiciona(prov);
                JOptionPane.showMessageDialog(this, "Datos grabados", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
                //grabar nuevo 

            } else {
                //grabar modificacion 
                Proveedor prov = new Proveedor(cod, nom, telef, direc, correo);
                cprov.modifica(prov);
                JOptionPane.showMessageDialog(this, "Datos Modificado y grabados", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
            }
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        }
    }//GEN-LAST:event_btnAgrega2ActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        op = 0;
        limpiaDatos();
        jtxtCodigo.setText("0");
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        op = 1;
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_btnModificarActionPerformed

    private void jtxtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNombreActionPerformed

    private void jtxtDireccActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDireccActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDireccActionPerformed

    private void jtxtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigoActionPerformed

    private void jtxttelefKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxttelefKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car)) || (car == ' ')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxttelefKeyTyped

    private void jtxtcorreoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtcorreoKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ') || (Character.isDefined(car))) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtcorreoKeyTyped

    private void jtxtDireccKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDireccKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ') || (Character.isDigit(car))) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtDireccKeyTyped

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1KeyReleased

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        Eimina();
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       Eimina();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        op = 1;
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jtxttelefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxttelefActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxttelefActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormProveedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormProveedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btnAgrega2;
    private javax.swing.JToggleButton btnBuscar;
    private javax.swing.JToggleButton btnEliminar;
    private javax.swing.JToggleButton btnImprime;
    private javax.swing.JToggleButton btnModificar;
    private javax.swing.JToggleButton btnNuevo;
    private javax.swing.JToggleButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jtxtCodigo;
    private javax.swing.JTextField jtxtDirecc;
    private javax.swing.JTextField jtxtNombre;
    private javax.swing.JTextField jtxtcorreo;
    private javax.swing.JTextField jtxttelef;
    // End of variables declaration//GEN-END:variables
}
