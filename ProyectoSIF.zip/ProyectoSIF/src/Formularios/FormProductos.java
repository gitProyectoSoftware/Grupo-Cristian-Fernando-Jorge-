/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Formularios;

import Modelo.Productos;
import Programas.ConexionBD;
import Programas.Cproducto;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import java.util.Date;  
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;



/**
 *
 * @author RYZEN XTREME
 */
public class FormProductos extends javax.swing.JFrame {

    Cproducto cprod = new Cproducto();

    long cod;
    String nom, tipo;
    int Stock;
    double precio;
    String lot, fecha;
    int op = 0;

    public FormProductos() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/Minifarmacia.png")).getImage());
        setBounds(50, 50, 950, 600);
        habilitaDatos(false);
        listadoGeneral();
        Calendar c2 = new GregorianCalendar();
        jDateChooser1.setCalendar(c2);
        nom ="%";

    }

    void recuperaDatosTabla() {
        int fila = jTable1.getSelectedRow();
        jtxtCodigo.setText(jTable1.getValueAt(fila, 0).toString());
        jtxtNombre.setText(jTable1.getValueAt(fila, 1).toString());
        JcomboTipo.setSelectedItem(jTable1.getValueAt(fila, 2).toString());
        jSpinnerStock.setValue(Integer.parseInt(jTable1.getValueAt(fila, 3).toString()));
        jtxtPrecio.setText(jTable1.getValueAt(fila, 4).toString());
        jtxtLote.setText(jTable1.getValueAt(fila, 5).toString());
        jDateChooser1.setDateFormatString((jTable1.getValueAt(fila, 6).toString()));
    }

    boolean validaDatos() {
        boolean sw = true;
        if (jtxtNombre.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el nombre", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtNombre.requestFocus();;
        } else if (JcomboTipo.getSelectedItem().toString().equals("(Seleccione tipo)")) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe seleccionar el tipo", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            JcomboTipo.requestFocus();;

        } else if (jtxtPrecio.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el precio", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtPrecio.requestFocus();;
        } else if (jtxtLote.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el Lote", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtLote.requestFocus();
        } else if (jDateChooser1.getDateFormatString().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar la fecha", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jDateChooser1.requestFocus();
        }
        return sw;
    }

    void limpiaDatos() {

        jtxtCodigo.setText("");
        jtxtNombre.setText("");
        JcomboTipo.setSelectedIndex(0);
        jSpinnerStock.setValue(1);
        jtxtPrecio.setText("");
        jtxtLote.setText("");
        jDateChooser1.setDateFormatString("jDateChooser1");

    }

    void Botones(boolean nuevo, boolean grabar, boolean mod, boolean del, boolean buscar, boolean imprime, boolean salir) {
        btnNuevo.setEnabled(nuevo);
        btnAgrega2.setEnabled(grabar);
        btnModificar.setEnabled(mod);
        btnEliminar.setEnabled(del);
        btnBuscar.setEnabled(buscar);
        btnImprime.setEnabled(imprime);
        btnSalir.setEnabled(salir);
    }

    void recuperaDatos() {
        try {
            cod = Long.parseLong(jtxtCodigo.getText());
            nom = jtxtNombre.getText();
            tipo = JcomboTipo.getSelectedItem().toString();
            Stock = Integer.parseInt(jSpinnerStock.getValue().toString());
            precio = Double.parseDouble(jtxtPrecio.getText());
            lot = jtxtLote.getText();
            fecha = jDateChooser1.getDateFormatString();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Uno de los datos numericos esta incorrecto ", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }

    void elimina() {
        int resp;
        int fila = jTable1.getSelectedRow();
        cod = Integer.parseInt(jTable1.getValueAt(fila, 0).toString());
        resp = JOptionPane.showConfirmDialog(this, "Desea eliminar", "INFORMACION - SIF ", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            cprod.Elimina(cod);
            listadoGeneral();
            JOptionPane.showMessageDialog(this, "Se elimino correctamente ", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No se elimino el dato seleccionado", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    void habilitaDatos(boolean hab) {
        jtxtCodigo.setEnabled(hab);
        jtxtNombre.setEnabled(hab);
        JcomboTipo.setEnabled(hab);
        jSpinnerStock.setEnabled(hab);
        jtxtPrecio.setEnabled(hab);
        jtxtLote.setEnabled(hab);
        jDateChooser1.setEnabled(hab);
    }

    void listadoGeneral() {
        ArrayList<Productos> lprod = new ArrayList();
        lprod = cprod.listarProductos();
        mostrar(lprod);
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }
    }

    void mostrar(ArrayList<Productos> lprod) {
        String mat[][] = new String[lprod.size()][7];
        int i;
        for (i = 0; i < lprod.size(); i++) {
            long cod = lprod.get(i).getCod();
            String nom = lprod.get(i).getNom();
            String tipo = lprod.get(i).getTipo();
            int stock = lprod.get(i).getStock();
            double precio = lprod.get(i).getPrecio();
            String lot = lprod.get(i).getLot();
            String fecha = lprod.get(i).getFecha();
            mat[i][0] = cod + "";
            mat[i][1] = nom + "";
            mat[i][2] = tipo + "";
            mat[i][3] = stock + "";
            mat[i][4] = precio + "";
            mat[i][5] = lot + "";
            mat[i][6] = fecha + "";
        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Codigo", "Nombre", "Tipo", "Stock", "Precio", "Lote", "Fecha Vencimiento"
                }
        ));
    }

    void listado() {
        nom = "";
        nom = JOptionPane.showInputDialog("Nombre del producto a buscar", "");
        if (nom.isEmpty()) {
            ArrayList<Productos> lprod = new ArrayList();
            lprod = cprod.listarProductos();
            mostrar(lprod);
        } else {
            ArrayList<Productos> lprod = new ArrayList();
            lprod = cprod.listarProdNombre(nom);
            mostrar(lprod);
        }
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jtxtCodigo = new javax.swing.JTextField();
        jtxtNombre = new javax.swing.JTextField();
        jtxtLote = new javax.swing.JTextField();
        jtxtPrecio = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        JcomboTipo = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jSpinnerStock = new javax.swing.JSpinner();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        btnNuevo = new javax.swing.JToggleButton();
        btnEliminar = new javax.swing.JToggleButton();
        btnAgrega2 = new javax.swing.JToggleButton();
        btnModificar = new javax.swing.JToggleButton();
        btnBuscar = new javax.swing.JToggleButton();
        btnImprime = new javax.swing.JToggleButton();
        btnSalir = new javax.swing.JToggleButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Consolas", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("PRODUCTOS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 203, 44));

        jTable1.setBackground(new java.awt.Color(51, 51, 51));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Tipo", "Stock", "Precio", "Lote", "Fecha Vencimiento"
            }
        ));
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 920, 260));

        jtxtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCodigoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 170, 30));

        jtxtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 170, 30));
        getContentPane().add(jtxtLote, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 170, 30));

        jtxtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtPrecioKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 170, 30));

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setText("Fecha Vencimiento");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, -1, 20));

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("Codigo:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 60, 20));

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("Nombre:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 60, 20));

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setText("TIpo: ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 60, 20));

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 0));
        jLabel6.setText("Stock:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 60, 20));

        JcomboTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "(Seleccione tipo)", "COMPRIMIDO", "AMPOLLAS", "TABLETA", "JARABE", "SOLUCION INYECTABLE", "SOBRE", "ENVASE ", " " }));
        getContentPane().add(JcomboTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 170, 30));

        jLabel8.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 0));
        jLabel8.setText("Precio:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 70, 60, 20));

        jLabel9.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 0));
        jLabel9.setText("Lote");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, 60, 20));

        jSpinnerStock.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jSpinnerStock.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jSpinnerStockKeyTyped(evt);
            }
        });
        getContentPane().add(jSpinnerStock, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, 170, 30));

        jDateChooser1.setMaxSelectableDate(new java.util.Date(253370782878000L));
        jDateChooser1.setMinSelectableDate(new java.util.Date(1104555678000L));
        getContentPane().add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 200, 170, 30));

        btnNuevo.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/listar.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 70, 140, 40));

        btnEliminar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 130, 150, 40));

        btnAgrega2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnAgrega2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agrega.png"))); // NOI18N
        btnAgrega2.setText("Grabar");
        btnAgrega2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgrega2ActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgrega2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 70, 150, 40));

        btnModificar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/modificar.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 140, 40));

        btnBuscar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscar.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, 140, 40));

        btnImprime.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnImprime.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/impresora.png"))); // NOI18N
        btnImprime.setText("Imprimir");
        btnImprime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimeActionPerformed(evt);
            }
        });
        getContentPane().add(btnImprime, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, -1, 40));

        btnSalir.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/atras (1).png"))); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setToolTipText("");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 250, 140, 40));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoSIF.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 960, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        listado();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnImprimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimeActionPerformed
            try {
            ConexionBD cone = new ConexionBD();
            Connection con = null;
            con = cone.conecta();
            String archivo ="C:/Users/jorge luis/Documents/NetBeansProjects/ProyectoSIF/src/Reprortes/ReProducto.jasper";
            JasperReport reporte = null;
            reporte = (JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro = new HashMap();
            nom = nom + "%";
            parametro.put("nom", nom);
            jp = JasperFillManager.fillReport(reporte, parametro, con);
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setTitle("REPORTES DE PRODUCTOS");
            jv.setVisible(true);
        } catch (JRException ex) {

        }
    }//GEN-LAST:event_btnImprimeActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        if (btnSalir.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        } else {
            FormPrincipal obj = new FormPrincipal();
        obj.setVisible(true);
        this.setVisible(false);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jtxtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodigoKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car))) {

        } else {
            evt.consume();

        }
    }//GEN-LAST:event_jtxtCodigoKeyTyped

    private void jtxtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNombreKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isLetter(car)) || (car == ' ') || Character.isDigit(car) || Character.isDefined(car)) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtNombreKeyTyped

    private void jSpinnerStockKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jSpinnerStockKeyTyped

    }//GEN-LAST:event_jSpinnerStockKeyTyped

    private void jtxtPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtPrecioKeyTyped
        char car = evt.getKeyChar();
        if ((Character.isDigit(car)) || (car == '.')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "INGRESE SOLO DATOS NUMERICOS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtPrecioKeyTyped

    private void btnAgrega2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgrega2ActionPerformed

        if (validaDatos() == true) {
            recuperaDatos();
            Date fecha_ven = jDateChooser1.getDate();
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat formato2 = new SimpleDateFormat("yyyy/MM/dd");
            String sfecha_ven = formato2.format(fecha_ven);

            if (op == 0) {
                Productos prod = new Productos(0, nom, tipo, Stock, precio, lot, sfecha_ven);
                cprod.adiciona(prod);
                JOptionPane.showMessageDialog(this, "Datos grabados", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
                //grabar nuevo 

            } else {
                //grabar modificacion

                Productos prod = new Productos(cod, nom, tipo, Stock, precio, lot, sfecha_ven);
                cprod.modifica(prod);
                JOptionPane.showMessageDialog(this, "Dato modificado y grabado", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
            }
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        }

    }//GEN-LAST:event_btnAgrega2ActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Calendar c2 = new GregorianCalendar();
        jDateChooser1.setCalendar(c2);
        op = 0;
        limpiaDatos();
        jtxtCodigo.setText("0");
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

        op = 1;
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_btnModificarActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1KeyReleased

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        elimina();

    }//GEN-LAST:event_btnEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JcomboTipo;
    private javax.swing.JToggleButton btnAgrega2;
    private javax.swing.JToggleButton btnBuscar;
    private javax.swing.JToggleButton btnEliminar;
    private javax.swing.JToggleButton btnImprime;
    private javax.swing.JToggleButton btnModificar;
    private javax.swing.JToggleButton btnNuevo;
    private javax.swing.JToggleButton btnSalir;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinnerStock;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jtxtCodigo;
    private javax.swing.JTextField jtxtLote;
    private javax.swing.JTextField jtxtNombre;
    private javax.swing.JTextField jtxtPrecio;
    // End of variables declaration//GEN-END:variables
}
