package Formularios;

import Modelo.Clientes;
import Programas.Ccliente;
import Programas.ConexionBD;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class FormClientes extends javax.swing.JFrame {

    Ccliente Cclie = new Ccliente();
    long cod;
    String nom, ApeP, ApeM;
    int CI, Tel;
    int op = 0;

    public FormClientes() {
        initComponents();
        setIconImage(new ImageIcon(getClass().getResource("/Imagenes/Minifarmacia.png")).getImage());
        setBounds(50, 50, 950, 600);
        habilitaDatos(false);
        listadoGeneral();
        nom="%";
    }

    void recuperaDatosTabla() {
        int fila = jTable1.getSelectedRow();
        jtxtCodigo.setText(jTable1.getValueAt(fila, 0).toString());
        jtxtNombre.setText(jTable1.getValueAt(fila, 1).toString());
        jtxtApellidoPaterno.setText(jTable1.getValueAt(fila, 2).toString());
        jtxtApellidoMaterno.setText(jTable1.getValueAt(fila, 3).toString());
        jtxtCI.setText(jTable1.getValueAt(fila, 4).toString());
        jtxtTelefono.setText(jTable1.getValueAt(fila, 5).toString());

    }

    boolean validaDatos() {
        boolean sw = true;

        if (jtxtNombre.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el nombre", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtNombre.requestFocus();;

        } else if (jtxtApellidoPaterno.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el Apellido_Paterno", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtApellidoPaterno.requestFocus();;
        } else if (jtxtApellidoMaterno.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el Apellido_Materno", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtApellidoMaterno.requestFocus();;
        } else if (jtxtCI.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el CI", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtCI.requestFocus();;
        } else if (jtxtTelefono.getText().trim().length() == 0) {
            sw = false;
            JOptionPane.showMessageDialog(this, "Debe ingresar el Telefono", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
            jtxtTelefono.requestFocus();
        }
        return sw;
    }

    void limpiaDatos() {
//
        jtxtCodigo.setText("");
        jtxtNombre.setText("");
        jtxtApellidoPaterno.setText("");
        jtxtApellidoMaterno.setText("");
        jtxtCI.setText("");
        jtxtTelefono.setText("");

    }

    void Botones(boolean nuevo, boolean grabar, boolean mod, boolean del, boolean buscar, boolean imprime, boolean salir) {
        btnNuevo.setEnabled(nuevo);
        btnAgrega2.setEnabled(grabar);
        btnModificar.setEnabled(mod);
        btnEliminar.setEnabled(del);
        btnBuscar.setEnabled(buscar);
        btnImprime.setEnabled(imprime);
        btnSalir.setEnabled(salir);
    }

    void recuperaDatos() {
        try {
            cod = Long.parseLong(jtxtCodigo.getText());
            nom = jtxtNombre.getText();
            ApeP = jtxtApellidoPaterno.getText();
            ApeM = jtxtApellidoMaterno.getText();
            CI = Integer.parseInt(jtxtCI.getText());
            Tel = Integer.parseInt(jtxtTelefono.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Uno de los datos numericos esta incorrecto ", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }

    void elimina() {
        int resp;
        int fila = jTable1.getSelectedRow();
        cod = Integer.parseInt(jTable1.getValueAt(fila, 0).toString());
        resp = JOptionPane.showConfirmDialog(this, "desea eliminar", "INFORMACION-SIF", JOptionPane.YES_NO_OPTION);
        if (resp == 0) {
            Cclie.elimina(cod);
            listadoGeneral();
            JOptionPane.showMessageDialog(this, "se elimino ", "INFORMACION-SIF", JOptionPane.YES_NO_OPTION);

        } else {
            JOptionPane.showMessageDialog(this, " no se elimino eldato seleccionado ", "INFORMACION-SIF", JOptionPane.YES_NO_OPTION);
        }
    }

    void habilitaDatos(boolean hab) {
        jtxtCodigo.setEnabled(hab);
        jtxtNombre.setEnabled(hab);
        jtxtApellidoPaterno.setEnabled(hab);
        jtxtApellidoMaterno.setEnabled(hab);
        jtxtCI.setEnabled(hab);
        jtxtTelefono.setEnabled(hab);

    }

    void listadoGeneral() {
        ArrayList<Clientes> lclie = new ArrayList();
        lclie = Cclie.listarClientes();
        mostrar(lclie);
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }
    }

    void mostrar(ArrayList<Clientes> lclie) {
        String mat[][] = new String[lclie.size()][6];
        int i;
        for (i = 0; i < lclie.size(); i++) {
            mat[i][0] = lclie.get(i).getCod() + "";
            mat[i][1] = lclie.get(i).getNom();
            mat[i][2] = lclie.get(i).getApeP();
            mat[i][3] = lclie.get(i).getApeM();
            mat[i][4] = lclie.get(i).getCI() + "";
            mat[i][5] = lclie.get(i).getTel() + "";

        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
                mat,
                new String[]{
                    "Codigo", "Nombre", "Apellido_Paterno", "Apellido_Materno", "CI", "Telefono"
                }
        ));
    }

    void listado() {
        nom = "";
        nom = JOptionPane.showInputDialog("Nombre del Cliente a buscar", "");
        if (nom.isEmpty()) {
            ArrayList<Clientes> lclie = new ArrayList();
            lclie = Cclie.listarClientes();
            mostrar(lclie);
        } else {
            ArrayList<Clientes> lclie = new ArrayList();
            lclie = Cclie.listarClieNombre(nom);
            mostrar(lclie);
        }
        if (jTable1.getRowCount() > 0) {
            Botones(true, false, true, true, true, true, true);
        } else {
            Botones(true, false, false, false, true, false, true);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jtxtCodigo = new javax.swing.JTextField();
        jtxtNombre = new javax.swing.JTextField();
        jtxtApellidoMaterno = new javax.swing.JTextField();
        jtxtApellidoPaterno = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JToggleButton();
        btnEliminar = new javax.swing.JToggleButton();
        btnAgrega2 = new javax.swing.JToggleButton();
        btnModificar = new javax.swing.JToggleButton();
        btnBuscar = new javax.swing.JToggleButton();
        btnImprime = new javax.swing.JToggleButton();
        btnSalir = new javax.swing.JToggleButton();
        jtxtCI = new javax.swing.JTextField();
        jtxtTelefono = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jMenuItem1.setText("Eliminar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("Modificar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Consolas", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Clientes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 203, 44));

        jTable1.setBackground(new java.awt.Color(51, 51, 51));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Apellido_Paterno", "Apellido_Materno", "CI", "Telefono"
            }
        ));
        jTable1.setComponentPopupMenu(jPopupMenu1);
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 920, 260));

        jtxtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigoActionPerformed(evt);
            }
        });
        jtxtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCodigoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 170, 30));

        jtxtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 170, 30));

        jtxtApellidoMaterno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtApellidoMaternoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtApellidoMaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 130, 170, 30));

        jtxtApellidoPaterno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtApellidoPaternoActionPerformed(evt);
            }
        });
        jtxtApellidoPaterno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtApellidoPaternoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtApellidoPaterno, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 170, 30));

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("Codigo:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 60, 20));

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setText("Nombre:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 60, 20));

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 0));
        jLabel5.setText("CI:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 80, 30));

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 0));
        jLabel6.setText("Telefono:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 60, -1));

        jLabel8.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 0));
        jLabel8.setText("Apellido_Paterno");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 120, 20));

        jLabel9.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 0));
        jLabel9.setText("Apellido_Materno");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, 120, 20));

        btnNuevo.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/listar.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 70, 140, 40));

        btnEliminar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 130, 150, 40));

        btnAgrega2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnAgrega2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agrega.png"))); // NOI18N
        btnAgrega2.setText("Grabar");
        btnAgrega2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgrega2ActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgrega2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 70, 150, 40));

        btnModificar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/modificar.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 140, 40));

        btnBuscar.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscar.png"))); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, 140, 40));

        btnImprime.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnImprime.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/impresora.png"))); // NOI18N
        btnImprime.setText("Imprimir");
        btnImprime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimeActionPerformed(evt);
            }
        });
        btnImprime.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                btnImprimeKeyTyped(evt);
            }
        });
        getContentPane().add(btnImprime, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 190, -1, 40));

        btnSalir.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/atras (1).png"))); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setToolTipText("");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 250, 120, 40));

        jtxtCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCIActionPerformed(evt);
            }
        });
        jtxtCI.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCIKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 170, 30));

        jtxtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTelefonoActionPerformed(evt);
            }
        });
        jtxtTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtTelefonoKeyTyped(evt);
            }
        });
        getContentPane().add(jtxtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 180, 170, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoSIF.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 930, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        listado();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnImprimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimeActionPerformed
        try {
            ConexionBD cone = new ConexionBD();
            Connection con = null;
            con = cone.conecta();
            String archivo = "C:/Users/jorge luis/Documents/NetBeansProjects/ProyectoSIF/src/Reprortes/ReporteCliente.jasper";
            JasperReport reporte = null;
            reporte = (JasperReport) JRLoader.loadObjectFromFile(archivo);
            JasperPrint jp;
            Map parametro = new HashMap();
            nom = nom + "%";
            parametro.put("Nom", nom);
            jp = JasperFillManager.fillReport(reporte, parametro, con);
            JasperViewer jv = new JasperViewer(jp, false);
            jv.setTitle("REPORTES DE CLIENTES");
            jv.setVisible(true);
        } catch (JRException ex) {

        }
    }//GEN-LAST:event_btnImprimeActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        if (btnSalir.getText().equals("Cancelar")) {
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        } else {
            FormPrincipal obj = new FormPrincipal();
        obj.setVisible(true);
        this.setVisible(false);
        }

    }//GEN-LAST:event_btnSalirActionPerformed

    private void jtxtApellidoPaternoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtApellidoPaternoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApellidoPaternoActionPerformed

    private void jtxtCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCIActionPerformed

    private void jtxtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTelefonoActionPerformed

    private void jtxtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodigoKeyTyped
        char car = evt.getKeyChar();

        if ((Character.isDigit(car))) {

        } else {
            evt.consume();

        }

    }//GEN-LAST:event_jtxtCodigoKeyTyped

    private void jtxtApellidoPaternoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApellidoPaternoKeyTyped
        char car = evt.getKeyChar();
        //     getToolkit().beep();
        if ((Character.isLetter(car)) || (car == ' ')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jtxtApellidoPaternoKeyTyped

    private void jtxtApellidoMaternoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApellidoMaternoKeyTyped
        char car = evt.getKeyChar();
        //    getToolkit().beep();
        if ((Character.isLetter(car)) || (car == ' ')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jtxtApellidoMaternoKeyTyped

    private void jtxtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNombreKeyTyped
        char car = evt.getKeyChar();
//        getToolkit().beep();
        if ((Character.isLetter(car)) || (car == ' ')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "SOLO SE ADMITEN LETRAS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jtxtNombreKeyTyped

    private void jtxtCIKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCIKeyTyped
        char car = evt.getKeyChar();
        //    getToolkit().beep();
        if ((Character.isDigit(car)) || (car == '.')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "INGRESE SOLO DATOS NUMERICOS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jtxtCIKeyTyped

    private void jtxtTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtTelefonoKeyTyped
        char car = evt.getKeyChar();
        //  getToolkit().beep();
        if ((Character.isDigit(car)) || (car == '.')) {
        } else {
            evt.consume();
            JOptionPane.showMessageDialog(this, "INGRESE SOLO DATOS NUMERICOS", "INFORMACION - SIF", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jtxtTelefonoKeyTyped

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        op = 0;
        limpiaDatos();
        jtxtCodigo.setText("0");
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnAgrega2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgrega2ActionPerformed
        if (validaDatos() == true) {
            recuperaDatos();
            if (op == 0) {
                Clientes clie = new Clientes(0, nom, ApeP, ApeM, CI, Tel);
                Cclie.adiciona(clie);
                JOptionPane.showMessageDialog(this, "Datos grabados", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
//grabar nuevo 

            } else {
                //grabar modificacion 
                Clientes clie = new Clientes(cod, nom, ApeP, ApeM, CI, Tel);
                Cclie.modifica(clie);
                JOptionPane.showMessageDialog(this, "Datos Modificados", "INFORMACION - SIF", JOptionPane.INFORMATION_MESSAGE);
            }
            listadoGeneral();
            habilitaDatos(false);
            btnSalir.setText("Salir");
        }

    }//GEN-LAST:event_btnAgrega2ActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

        op = 1;
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");

    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        elimina();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jtxtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigoActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyReleased
        recuperaDatosTabla();
    }//GEN-LAST:event_jTable1KeyReleased

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        elimina();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        op = 1;
        habilitaDatos(true);
        Botones(false, true, false, false, false, false, true);
        btnSalir.setText("Cancelar");
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void btnImprimeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnImprimeKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_btnImprimeKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btnAgrega2;
    private javax.swing.JToggleButton btnBuscar;
    private javax.swing.JToggleButton btnEliminar;
    private javax.swing.JToggleButton btnImprime;
    private javax.swing.JToggleButton btnModificar;
    private javax.swing.JToggleButton btnNuevo;
    private javax.swing.JToggleButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jtxtApellidoMaterno;
    private javax.swing.JTextField jtxtApellidoPaterno;
    private javax.swing.JTextField jtxtCI;
    private javax.swing.JTextField jtxtCodigo;
    private javax.swing.JTextField jtxtNombre;
    private javax.swing.JTextField jtxtTelefono;
    // End of variables declaration//GEN-END:variables
}
